import fs from 'node:fs';
import path from 'node:path';

const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const files=fs.readdirSync(root).filter(name=>name.endsWith('.html'));
const failures=[];
const required=['index.html','login.html','signup.html','dashboard.html','profile.html','card.html','account.html','journey.html','employer-dashboard.html','university-dashboard.html','university-admin.html','forgot-password.html','reset-password.html'];
for(const name of required)if(!fs.existsSync(path.join(root,name)))failures.push(`Missing required page: ${name}`);
for(const name of files){
  const html=fs.readFileSync(path.join(root,name),'utf8');
  const ids=[...html.matchAll(/\sid=["']([^"']+)["']/g)].map(m=>m[1]);
  const duplicate=[...new Set(ids.filter((id,i)=>ids.indexOf(id)!==i))];
  if(duplicate.length)failures.push(`${name}: duplicate IDs ${duplicate.join(', ')}`);
  for(const match of html.matchAll(/(?:href|src)=["']([^"']+)["']/g)){
    const ref=match[1].split('?')[0];
    if(!ref||ref.includes('${')||/^(?:https?:|#|mailto:|tel:|data:|javascript:)/.test(ref))continue;
    if(!fs.existsSync(path.join(root,ref)))failures.push(`${name}: missing local reference ${ref}`);
  }
}
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
for(const helper of ['profileUrl','signedFileUrl','requireUser'])if(!app.includes(`${helper}(`))failures.push(`app.js: missing ${helper}`);
const dashboard=fs.readFileSync(path.join(root,'dashboard.html'),'utf8');
if(dashboard.includes('tapid.publicProfileUrl('))failures.push('dashboard.html: stale publicProfileUrl call');
const migration=fs.readFileSync(path.join(root,'tapid_v2_production_migration.sql'),'utf8');
for(const table of ['career_fairs','career_fair_employers','card_issuance','recommendations','career_outcomes'])if(!migration.includes(`public.${table}`))failures.push(`migration: missing ${table}`);
if(failures.length){console.error(failures.join('\n'));process.exit(1);}
console.log(`TapID smoke checks passed across ${files.length} HTML pages.`);
