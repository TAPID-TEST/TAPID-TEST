TapID V1 — Sprint 3B

Adds to the verified Sprint 3A build:
- Skills with Add/Edit/Delete/Hide
- Evidence links from skills to experiences and projects
- Public skill cards showing where each skill was demonstrated
- Organizations with Add/Edit/Delete/Hide
- Certifications with Add/Edit/Delete/Hide and optional credential URL
- Public Organizations and Certifications sections

Before deployment, run sprint3b_backend_patch.sql once in Supabase SQL Editor.
Then redeploy this entire folder to the existing V1 Netlify site.

Sprint 3B certificate update: run sprint3b_certificate_patch.sql before redeploying. Certifications now support one JPG/PNG/WebP/PDF document with replace/delete and public viewing.
